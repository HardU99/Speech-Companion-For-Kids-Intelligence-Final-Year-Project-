from project import app

app.run(port=4270, threaded=True)
