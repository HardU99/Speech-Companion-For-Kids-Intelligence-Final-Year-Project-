import warnings
from datetime import timedelta
from flask_sqlalchemy import SQLAlchemy

from flask import Flask

app = Flask(__name__)

warnings.filterwarnings("ignore", category=FutureWarning)

warnings.filterwarnings("ignore", category=DeprecationWarning)

app.secret_key = 'sessionData'

app.config['TESTING'] = True

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

app.config['SQLALCHEMY_ECHO'] = True

app.config['SQLALCHEMY_RECORD_QUERIES'] = True

# app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root@localhost:3306/pythondb'

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:rootroot@rdspython.cwcmitdkbwwk.us-east-1.rds.amazonaws.com:3306/pythondb'

app.config['SQLALCHEMY_MAX_OVERFLOW'] = 0

app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=3)

db = SQLAlchemy(app)

ACCESS_KEY = "AKIAIJJJEXWI6SHUT5QA"

SECRET_KEY = "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"

import project.com.controller
