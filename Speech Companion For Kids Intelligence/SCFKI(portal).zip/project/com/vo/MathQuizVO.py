from project import db


class MathQuizVO(db.Model):
    __tablename__ = "mathquizmaster"
    mathQuizId = db.Column("mathQuizId", db.BigInteger, primary_key=True, autoincrement=True)
    mathQuizQuestion = db.Column("mathQuizQuestion", db.String(500))
    mathQuizAnswer = db.Column("mathQuizAnswer", db.String(500))

    def as_dict(self):
        return {
            'mathQuizId': self.mathQuizId,
            'mathQuizQuestion': self.mathQuizQuestion,
            'mathQuizAnswer': self.mathQuizAnswer
        }


db.create_all()
