from project import db
from project.com.vo.StoryTypeVO import StoryTypeVO


class StoryVO(db.Model):
    __tablename__ = "storymaster"
    storyId = db.Column("storyId", db.BigInteger, primary_key=True, autoincrement=True)
    storyTitle = db.Column("storyTitle", db.String(100))
    storyFileName = db.Column("storyFileName", db.String(100))
    storyFilePath = db.Column("storyFilePath", db.String(100))
    storyFileLink = db.Column("storyFileLink", db.String(200))
    storyImageName = db.Column("storyImageName", db.String(100))
    storyImagePath = db.Column("storyImagePath", db.String(100))
    storyImageLink = db.Column("storyImageLink", db.String(200))
    storyMoral = db.Column("storyMoral", db.String(500))
    story_StoryTypeId = db.Column("story_StoryTypeId", db.BigInteger, db.ForeignKey(StoryTypeVO.storyTypeId))

    def as_dict(self):
        return {
            'storyId': self.storyId,
            'storyTitle': self.storyTitle,
            'storyFileName': self.storyFileName,
            'storyFilePath': self.storyFilePath,
            'storyFileLink': self.storyFileLink,
            'storyImageName': self.storyImageName,
            'storyImagePath': self.storyImagePath,
            'storyImageLink': self.storyImageLink,
            'storyMoral': self.storyMoral,
            'story_StoryTypeId': self.story_StoryTypeId
        }


db.create_all()
