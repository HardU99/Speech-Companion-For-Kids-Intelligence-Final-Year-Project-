from project import db
from project.com.vo.LoginVO import LoginVO
from project.com.vo.PackageVO import PackageVO


class PurchaseVO(db.Model):
    __tablename__ = "purchasemaster"
    purchaseId = db.Column('purchaseId', db.BigInteger, primary_key=True, autoincrement=True)
    purchaseDate = db.Column('purchaseDate', db.String(500))
    purchaseTime = db.Column('purchaseTime', db.String(100))
    purchase_LoginId = db.Column('purchase_LoginId', db.BigInteger, db.ForeignKey(LoginVO.loginId))
    purchase_PackageId = db.Column('purchase_PackageId', db.BigInteger, db.ForeignKey(PackageVO.packageId))

    def as_dict(self):
        return {
            'purchaseId': self.purchaseId,
            'purchaseDate': self.purchaseDate,
            'purchaseTime': self.purchaseTime,
            'purchase_LoginId': self.purchase_LoginId,
            'purchase_PackageId': self.purchase_PackageId
        }


db.create_all()
