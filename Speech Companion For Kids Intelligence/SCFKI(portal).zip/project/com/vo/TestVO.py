from project import db
from project.com.vo.LoginVO import LoginVO
from project.com.vo.StoryVO import StoryVO


class TestVO(db.Model):
    __tablename__ = "testmaster"
    testId = db.Column("testId", db.BigInteger, primary_key=True, autoincrement=True)
    testTopic = db.Column("testTopic", db.String(10))
    testScore = db.Column("testScore", db.String(10))
    testGrade = db.Column("testGrade", db.String(10))
    testDate = db.Column("testDate", db.DATE)
    testTime = db.Column("testTime", db.TIME)
    test_LoginId = db.Column("test_LoginId", db.BigInteger, db.ForeignKey(LoginVO.loginId))

    def as_dict(self):
        return {
            'testId': self.testId,
            'testTopic': self.testTopic,
            'testScore': self.testScore,
            'testGrade': self.testGrade,
            'testDate': self.testDate,
            'testTime': self.testTime,
            'test_LoginId': self.test_LoginId
        }


db.create_all()
