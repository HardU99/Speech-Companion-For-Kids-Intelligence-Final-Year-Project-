from project import db


class PoemVO(db.Model):
    __tablename__ = "poemmaster"
    poemId = db.Column("poemId", db.BigInteger, primary_key=True, autoincrement=True)
    poemTitle = db.Column("poemTitle", db.String(100))
    poemFileName = db.Column("poemFileName", db.String(100))
    poemFilePath = db.Column("poemFilePath", db.String(100))
    poemFileLink = db.Column("poemFileLink", db.String(200))
    poemImageName = db.Column("poemImageName", db.String(100))
    poemImagePath = db.Column("poemImagePath", db.String(100))
    poemImageLink = db.Column("poemImageLink", db.String(200))

    def as_dict(self):
        return {
            'poemId': self.poemId,
            'poemTitle': self.poemTitle,
            'poemFileName': self.poemFileName,
            'poemFilePath': self.poemFilePath,
            'poemImageName': self.poemImageName,
            'poemImagePath': self.poemImagePath,
            'poemImageLink': self.poemImageLink
        }


db.create_all()
