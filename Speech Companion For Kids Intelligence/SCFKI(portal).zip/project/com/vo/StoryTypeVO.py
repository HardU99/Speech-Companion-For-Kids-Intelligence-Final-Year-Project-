from project import db


class StoryTypeVO(db.Model):
    __tablename__ = "storytypemaster"
    storyTypeId = db.Column("storyTypeId", db.BigInteger, primary_key=True, autoincrement=True)
    storyType = db.Column("storyType", db.String(100), unique=True)
    storyTypeDescription = db.Column("storyTypeDescription", db.String(500))
    storyTypeImageName = db.Column("storyTypeImageName", db.String(100))
    storyTypeImagePath = db.Column("storyTypeImagePath", db.String(100))
    storyTypeImageLink = db.Column("storyTypeImageLink", db.String(200))

    def as_dict(self):
        return {
            'storyTypeId': self.storyTypeId,
            'storyType': self.storyType,
            'storyTypeDescription': self.storyTypeDescription,
            'storyTypeImageName': self.storyTypeImageName,
            'storyTypeImagePath': self.storyTypeImagePath,
            'storyTypeImageLink': self.storyTypeImageLink
        }


db.create_all()
