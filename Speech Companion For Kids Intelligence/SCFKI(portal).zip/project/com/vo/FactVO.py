from project import db
from project.com.vo.FactTypeVO import FactTypeVO


class FactVO(db.Model):
    __tablename__ = "factmaster"
    factId = db.Column("factId", db.BigInteger, primary_key=True, autoincrement=True)
    fact = db.Column("fact", db.String(100))
    factImageName = db.Column("factImageName", db.String(100))
    factImagePath = db.Column("factImagePath", db.String(100))
    factImageLink = db.Column("factImageLink", db.String(200))
    fact_FactTypeId = db.Column("fact_FactTypeId", db.BigInteger, db.ForeignKey(FactTypeVO.factTypeId))

    def as_dict(self):
        return {
            'factId': self.factId,
            'fact': self.factTitlefact,
            'factImageName': self.factImageName,
            'factImagePath': self.factImagePath,
            'factImageLink': self.factImageLink,
            'fact_FactTypeId': self.fact_FactTypeId
        }


db.create_all()
