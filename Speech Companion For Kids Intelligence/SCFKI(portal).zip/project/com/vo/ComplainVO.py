from project import db
from project.com.vo.LoginVO import LoginVO


class ComplainVO(db.Model):
    __tablename__ = "complainmaster"
    complainId = db.Column("complainId", db.BigInteger, primary_key=True, autoincrement=True)
    complainSubject = db.Column("complainSubject", db.String(100))
    complainDescription = db.Column("complainDescription", db.String(1000))
    complainDate = db.Column("complainDate", db.DATE)
    complainTime = db.Column("complainTime", db.TIME)
    complainStatus = db.Column("complainStatus", db.String(20))
    complainFileName = db.Column("complainFileName", db.String(100))
    complainFilePath = db.Column("complainFilePath", db.String(200))
    complainTo_LoginId = db.Column("complainTo_LoginId", db.BigInteger, db.ForeignKey(LoginVO.loginId))
    complainFrom_LoginId = db.Column("complainFrom_LoginId", db.BigInteger, db.ForeignKey(LoginVO.loginId))
    replySubject = db.Column("replySubject", db.String(100), nullable=True)
    replyMessage = db.Column("replyMessage", db.String(1000), nullable=True)
    replyFileName = db.Column("replyFileName", db.String(100), nullable=True)
    replyFilePath = db.Column("replyFilePath", db.String(200), nullable=True)
    replyDate = db.Column("replyDate", db.DATE, nullable=True)
    replyTime = db.Column("replyTime", db.TIME, nullable=True)

    def as_dict(self):
        return {
            'complainId': self.complainId,
            'complainSubject': self.complainSubject,
            'complainDescription': self.complainDescription,
            'complainDate': self.complainDate,
            'complainTime': self.complainTime,
            'complainStatus': self.complainStatus,
            'complainFileName': self.complainFileName,
            'complainFilePath': self.complainFilePath,
            'complainTo_LoginId': self.complainTo_LoginId,
            'complainFrom_LoginId': self.complainFrom_LoginId,
            'replySubject': self.replySubject,
            'replyMessage': self.replyMessage,
            'replyFileName': self.replyFileName,
            'replyFilePath': self.replyFilePath,
            'replyDate': self.replyDate,
            'replyTime': self.replyTime
        }


db.create_all()
