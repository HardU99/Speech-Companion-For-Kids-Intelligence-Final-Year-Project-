from project import db


class FactTypeVO(db.Model):
    __tablename__ = "facttypemaster"
    factTypeId = db.Column("factTypeId", db.BigInteger, primary_key=True, autoincrement=True)
    factType = db.Column("factType", db.String(100), unique=True)
    factTypeDescription = db.Column("factTypeDescription", db.String(500))
    factTypeImageName = db.Column("factTypeImageName", db.String(100))
    factTypeImagePath = db.Column("factTypeImagePath", db.String(100))
    factTypeImageLink = db.Column("factTypeImageLink", db.String(200))

    def as_dict(self):
        return {
            'factTypeId': self.factTypeId,
            'factType': self.factType,
            'factTypeDescription': self.factTypeDescription,
            'factTypeImageName': self.factTypeImageName,
            'factTypeImagePath': self.factTypeImagePath,
            'factTypeImageLink': self.factTypeImageLink
        }


db.create_all()
