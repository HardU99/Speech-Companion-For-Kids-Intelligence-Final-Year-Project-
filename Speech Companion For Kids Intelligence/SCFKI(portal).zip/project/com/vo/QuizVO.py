from project import db
from project.com.vo.StoryTypeVO import StoryTypeVO
from project.com.vo.StoryVO import StoryVO


class QuizVO(db.Model):
    __tablename__ = "quizmaster"
    quizId = db.Column("quizId", db.BigInteger, primary_key=True, autoincrement=True)
    quizQuestion = db.Column("quizQuestion", db.String(500))
    quizAnswer = db.Column("quizAnswer", db.String(500))
    quiz_StoryTypeId = db.Column("quiz_StoryTypeId", db.BigInteger, db.ForeignKey(StoryTypeVO.storyTypeId))
    quiz_StoryId = db.Column("quiz_StoryId", db.BigInteger, db.ForeignKey(StoryVO.storyId))

    def as_dict(self):
        return {
            'quizId': self.quizId,
            'quizQuestion': self.quizQuestion,
            'quizAnswer': self.quizAnswer,
            'quiz_StoryTypeId': self.quiz_StoryTypeId,
            'quiz_StoryId': self.quiz_StoryId
        }


db.create_all()
