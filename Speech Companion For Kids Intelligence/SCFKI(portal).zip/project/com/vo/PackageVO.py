from project import db


class PackageVO(db.Model):
    __tablename__ = "packagemaster"
    packageId = db.Column('packageId', db.BigInteger, primary_key=True, autoincrement=True)
    packageName = db.Column('packageName', db.String(100))
    packageDescription = db.Column('packageDescription', db.String(1000))
    packageDuration = db.Column('packageDuration', db.String(10))
    packagePrice = db.Column('packagePrice', db.Integer)

    def as_dict(self):
        return {
            'packageId': self.packageId,
            'packageName': self.packageName,
            'packageDescription': self.packageDescription,
            'packageDuration': self.packageDuration,
            'packagePrice': self.packagePrice
        }


db.create_all()
