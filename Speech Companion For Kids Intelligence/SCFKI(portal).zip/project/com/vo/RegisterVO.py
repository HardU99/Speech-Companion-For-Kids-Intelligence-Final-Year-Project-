from project import db
from project.com.vo.LoginVO import LoginVO


class RegisterVO(db.Model):
    __tablename__ = "registermaster"
    registerId = db.Column("registerId", db.BigInteger, primary_key=True, autoincrement=True)
    registerChildName = db.Column("registerChildName", db.String(50), nullable=False)
    registerChildBirthDate = db.Column("registerChildBirthDate", db.DATE, nullable=False)
    registerChildGender = db.Column("registerChildGender", db.String(10), nullable=False)
    registerParentName = db.Column("registerParentName", db.String(50), nullable=False)
    registerContact = db.Column("registerContact", db.BigInteger, nullable=False)
    registerAddress = db.Column("registerAddress", db.String(500), nullable=False)
    register_LoginId = db.Column("register_LoginId", db.BigInteger, db.ForeignKey(LoginVO.loginId))

    def as_dict(self):
        return {
            'registerId': self.registerId,
            'registerChildName': self.registerChildName,
            'registerChildBirthDate': self.registerChildBirthDate,
            'registerChildGender': self.registerChildGender,
            'registerParentName': self.registerParentName,
            'registerContact': self.registerContact,
            'registerAddress': self.registerAddress,
            'register_LoginId': self.register_LoginId
        }


db.create_all()
