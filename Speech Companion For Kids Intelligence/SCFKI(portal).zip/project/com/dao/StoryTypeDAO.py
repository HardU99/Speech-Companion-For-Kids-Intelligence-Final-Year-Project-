from project import db
from project.com.vo.StoryTypeVO import StoryTypeVO


class StoryTypeDAO:
    def insertStoryType(self, storyTypeVO):
        db.session.add(storyTypeVO)
        db.session.commit()

    def viewStoryType(self):
        storyTypeList = StoryTypeVO.query.all()
        return storyTypeList

    def deleteStoryType(self, storyTypeVO):
        storyTypeList = StoryTypeVO.query.get(storyTypeVO.storyTypeId)
        db.session.delete(storyTypeList)
        db.session.commit()
        return storyTypeList

    def editStoryType(self, storyTypeVO):
        storyTypeList = StoryTypeVO.query.filter_by(storyTypeId=storyTypeVO.storyTypeId).all()
        return storyTypeList

    def updateStoryType(self, storyTypeVO):
        db.session.merge(storyTypeVO)
        db.session.commit()
