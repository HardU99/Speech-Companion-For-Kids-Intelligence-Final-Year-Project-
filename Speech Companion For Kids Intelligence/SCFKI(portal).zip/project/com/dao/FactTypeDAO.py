from project import db
from project.com.vo.FactTypeVO import FactTypeVO


class FactTypeDAO:
    def insertFactType(self, factTypeVO):
        db.session.add(factTypeVO)
        db.session.commit()

    def viewFactType(self):
        factTypeList = FactTypeVO.query.all()
        return factTypeList

    def deleteFactType(self, factTypeVO):
        factTypeList = FactTypeVO.query.get(factTypeVO.factTypeId)
        db.session.delete(factTypeList)
        db.session.commit()
        return factTypeList

    def editFactType(self, factTypeVO):
        factTypeList = FactTypeVO.query.filter_by(factTypeId=factTypeVO.factTypeId).all()
        return factTypeList

    def updateFactType(self, factTypeVO):
        db.session.merge(factTypeVO)
        db.session.commit()

    def detailsFactType(self, factTypeId):
        factTypeList = FactTypeVO.query.get(factTypeId)
        return factTypeList