from project import db
from project.com.vo.StoryTypeVO import StoryTypeVO
from project.com.vo.StoryVO import StoryVO


class StoryDAO:
    def insertStory(self, storyVO):
        db.session.add(storyVO)
        db.session.commit()

    def viewStory(self):
        storyList = db.session.query(StoryVO, StoryTypeVO).join(StoryTypeVO,
                                                                StoryVO.story_StoryTypeId == StoryTypeVO.storyTypeId).all()
        return storyList

    def searchStoryType(self):
        storyList = StoryVO.query.all()
        return storyList

    def deleteStory(self, storyVO):
        storyList = StoryVO.query.get(storyVO.storyId)
        db.session.delete(storyList)
        db.session.commit()
        return storyList

    def editStory(self, storyVO):
        storyList = StoryVO.query.filter_by(storyId=storyVO.storyId).all()
        return storyList

    def updateStory(self, storyVO):
        db.session.merge(storyVO)
        db.session.commit()

