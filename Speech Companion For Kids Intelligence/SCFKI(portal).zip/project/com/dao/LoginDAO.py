from project import db
from project.com.vo.LoginVO import LoginVO


class LoginDAO:
    def insertLogin(self, loginVO):
        db.session.add(loginVO)
        db.session.commit()

    def validateLogin(self, loginVO):
        loginList = LoginVO.query.filter_by(loginUsername=loginVO.loginUsername, loginPassword=loginVO.loginPassword)
        return loginList

    def validateLoginStatus(self, loginVO):
        loginList = LoginVO.query.filter_by(loginUsername=loginVO.loginUsername, loginStatus=loginVO.loginStatus)
        return loginList

    def validateLoginUsername(self, loginVO):
        loginList = LoginVO.query.filter_by(loginUsername=loginVO.loginUsername)
        return loginList

    def fetchUsername(self, loginId):
        loginVOList = LoginVO.query.filter_by(loginId=loginId)
        return loginVOList

    def updateLogin(self, loginVO):
        db.session.merge(loginVO)
        db.session.commit()

    def getUserCount(self):
        userList = LoginVO.query.filter_by(loginRole='user').count()
        return userList

    def getUserList(self):
        userList = LoginVO.query.all()
        return userList

    def getActiveUser(self):
        activeUserList = LoginVO.query.filter_by(loginRole='user', loginStatus='active').count()
        return activeUserList
