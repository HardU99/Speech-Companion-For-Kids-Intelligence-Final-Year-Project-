from project import db
from project.com.vo.QuizVO import QuizVO
from project.com.vo.StoryTypeVO import StoryTypeVO
from project.com.vo.StoryVO import StoryVO


class QuizDAO:
    def insertQuiz(self, quizVO):
        db.session.add(quizVO)
        db.session.commit()

    def viewQuiz(self):
        quizList = db.session.query(QuizVO, StoryVO, StoryTypeVO).join(StoryVO,
                                                                       QuizVO.quiz_StoryId == StoryVO.storyId).join(
            StoryTypeVO, QuizVO.quiz_StoryTypeId == StoryTypeVO.storyTypeId).all()
        return quizList

    def deleteQuiz(self, quizVO):
        quizList = quizVO.query.get(quizVO.quizId)
        db.session.delete(quizList)
        db.session.commit()

    def editQuiz(self, quizVO):
        quizList = quizVO.query.filter_by(quizId=quizVO.quizId).all()
        return quizList

    def updateQuiz(self, quizVO):
        db.session.merge(quizVO)
        db.session.commit()

