from flask import session

from project import db
from project.com.vo.LoginVO import LoginVO
from project.com.vo.StoryVO import StoryVO
from project.com.vo.TestVO import TestVO


class TestDAO:
    def adminViewTest(self):
        testList = db.session.query(TestVO, LoginVO). \
            join(LoginVO, TestVO.test_LoginId == LoginVO.loginId).all()
        return testList

    def userViewTest(self):
        testList = db.session.query(TestVO). \
            filter_by(test_LoginId=session['session_loginId']).all()
        return testList

    def deleteTest(self, testVO):
        testList = TestVO.query.get(testVO.testId)
        db.session.delete(testList)
        db.session.commit()
