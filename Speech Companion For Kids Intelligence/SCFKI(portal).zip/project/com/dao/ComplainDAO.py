from project import db
from project.com.vo.ComplainVO import ComplainVO
from project.com.vo.LoginVO import LoginVO


class ComplainDAO:
    def insertComplain(self, complainVO):
        db.session.add(complainVO)
        db.session.commit()

    def viewComplain(self):
        complainList = db.session.query(ComplainVO, LoginVO).join(LoginVO,
                                                                  ComplainVO.complainFrom_LoginId == LoginVO.loginId).all()
        return complainList

    def deleteComplain(self, complainVO):
        complainList = ComplainVO.query.get(complainVO.complainId)
        db.session.delete(complainList)
        db.session.commit()
        return complainList

    def viewComplainReply(self, complainReplyList):
        complainReplyList = ComplainVO.query.filter_by(complainId=complainReplyList.complainId)
        return complainReplyList

    def insertComplainReply(self, complainVO):
        db.session.merge(complainVO)
        db.session.commit()

    def totalComplains(self):
        complains = ComplainVO.query.filter(ComplainVO.complainId).count()
        return complains

    def totalPendingComplains(self):
        pendingComplains = ComplainVO.query.filter_by(complainStatus='pending').count()
        return pendingComplains

    def totalUserComplains(self,loginId):
        complains = ComplainVO.query.filter_by(complainFrom_LoginId=loginId).count()
        return complains

    def totalUserPendingComplains(self,loginId):
        pendingComplains = ComplainVO.query.filter_by(complainFrom_LoginId=loginId).filter_by(complainStatus='pending').count()
        return pendingComplains