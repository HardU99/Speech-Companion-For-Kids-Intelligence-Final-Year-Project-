from flask import session

from project import db
from project.com.vo.PackageVO import PackageVO
from project.com.vo.PurchaseVO import PurchaseVO


class PurchaseDAO:
    def insertPurchase(self, purchaseVO):
        db.session.add(purchaseVO)
        db.session.commit()

    def viewPurchase(self):
        purchaseList = db.session.query(PurchaseVO, PackageVO). \
            filter_by(purchase_LoginId=session['session_loginId']). \
            join(PackageVO, PurchaseVO.purchase_PackageId == PackageVO.packageId).all()
        return purchaseList

    def viewPurchasedPackage(self):
        puchasedPackageList=PurchaseVO.query.filter_by(purchase_LoginId=session['session_loginId']).all()
        return puchasedPackageList

