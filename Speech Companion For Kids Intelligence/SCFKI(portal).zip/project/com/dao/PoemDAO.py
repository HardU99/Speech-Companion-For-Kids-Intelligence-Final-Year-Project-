from project import db
from project.com.vo.PoemVO import PoemVO


class PoemDAO:
    def insertPoem(self, poemVO):
        db.session.add(poemVO)
        db.session.commit()

    def viewPoem(self):
        poemList = PoemVO.query.all()
        return poemList

    def deletePoem(self, poemVO):
        poemList = PoemVO.query.get(poemVO.poemId)
        db.session.delete(poemList)
        db.session.commit()
        return poemList

    def editPoem(self, poemVO):
        poemList = PoemVO.query.filter_by(poemId=poemVO.poemId).all()
        return poemList

    def updatePoem(self, poemVO):
        db.session.merge(poemVO)
        db.session.commit()