from project import db
from project.com.vo.FactTypeVO import FactTypeVO
from project.com.vo.FactVO import FactVO


class FactDAO:
    def insertFact(self, factVO):
        db.session.add(factVO)
        db.session.commit()

    def viewFact(self):
        factList = db.session.query(FactVO, FactTypeVO).join(FactTypeVO,
                                                                FactVO.fact_FactTypeId == FactTypeVO.factTypeId).all()
        return factList

    def searchFactType(self):
        factList = FactVO.query.all()
        return factList

    def deleteFact(self, factVO):
        factList = FactVO.query.get(factVO.factId)
        db.session.delete(factList)
        db.session.commit()
        return factList

    def editFact(self, factVO):
        factList = FactVO.query.filter_by(factId=factVO.factId).all()
        return factList

    def updateFact(self, factVO):
        db.session.merge(factVO)
        db.session.commit()