from project import db
from project.com.vo.MathQuizVO import MathQuizVO

class MathQuizDAO:
    def insertMathQuiz(self, mathQuizVO):
        db.session.add(mathQuizVO)
        db.session.commit()

    def viewMathQuiz(self):
        mathQuizList = MathQuizVO.query.all()
        return mathQuizList

    def deleteMathQuiz(self, mathQuizVO):
        mathQuizList = mathQuizVO.query.get(mathQuizVO.mathQuizId)
        db.session.delete(mathQuizList)
        db.session.commit()

    def editMathQuiz(self, mathQuizVO):
        mathQuizList = mathQuizVO.query.filter_by(mathQuizId=mathQuizVO.mathQuizId).all()
        return mathQuizList

    def updateMathQuiz(self, mathQuizVO):
        db.session.merge(mathQuizVO)
        db.session.commit()