from datetime import datetime, date

from flask import request, redirect, url_for, session, render_template

from project import app
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.PurchaseDAO import PurchaseDAO
from project.com.vo.PurchaseVO import PurchaseVO


@app.route('/user/insertPurchase')
def userInsertPurchase():
    try:
        if adminLoginSession() == "user":

            time = datetime.now()
            packageId = request.args.get("packageId")

            purchaseVO = PurchaseVO()
            purchaseDAO = PurchaseDAO()

            purchaseVO.purchaseDate = date.today()
            purchaseVO.purchaseTime = time.strftime("%H:%M:%S")
            purchaseVO.purchase_LoginId = session['session_loginId']
            purchaseVO.purchase_PackageId = packageId
            purchaseDAO.insertPurchase(purchaseVO)

            return redirect(url_for('userViewPurchase'))
        else:
            return redirect(url_for("adminLogoutSession"))

    except Exception as ex:
        print(ex)


@app.route('/user/viewPurchase')
def userViewPurchase():
    try:
        if adminLoginSession() == "user":

            puchaseDAO = PurchaseDAO()
            purchaseList = puchaseDAO.viewPurchase()
            return render_template('user/viewPurchase.html', purchaseList=purchaseList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
