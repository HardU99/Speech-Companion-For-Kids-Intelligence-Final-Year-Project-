import os

import boto3
from flask import render_template, url_for, request, redirect
from werkzeug.utils import secure_filename

from project import app, ACCESS_KEY, SECRET_KEY
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.StoryDAO import StoryDAO
from project.com.dao.StoryTypeDAO import StoryTypeDAO
from project.com.vo.StoryVO import StoryVO


@app.route("/admin/loadStory")
def adminLoadStory():
    try:
        if adminLoginSession() == "admin":
            storyTypeDAO = StoryTypeDAO()
            storyTypeList = storyTypeDAO.viewStoryType()
            return render_template("admin/addStory.html", storyTypeList=storyTypeList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/insertStory", methods=['POST', 'GET'])
def adminInsertStory():
    try:
        if adminLoginSession() == "admin":

            UPLOAD_FOLDER = "../scfki/project/static/adminResources/Story/"
            app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

            storyTitle = request.form['storyTitle']
            storyFile = request.files['storyFile']
            storyImage = request.files['storyImage']
            storyMoral = request.form['storyMoral']
            story_StoryTypeId = request.form['story_StoryTypeId']

            storyFileName = secure_filename(storyFile.filename)
            storyFilePath = os.path.join(app.config['UPLOAD_FOLDER'])
            storyFile.save(os.path.join(storyFilePath, storyFileName))

            storyImageName = secure_filename(storyImage.filename)
            storyImagePath = os.path.join(app.config['UPLOAD_FOLDER'])
            storyImage.save(os.path.join(storyImagePath, storyImageName))

            storyVO = StoryVO()
            storyDAO = StoryDAO()

            storyVO.story_StoryTypeId = story_StoryTypeId
            storyVO.storyTitle = storyTitle
            storyVO.storyFileName = storyFileName
            storyVO.storyImageName = storyImageName
            storyVO.storyFilePath = storyFilePath.replace("scfki/project", "..")
            storyVO.storyImagePath = storyImagePath.replace("scfki/project", "..")
            storyVO.storyMoral = storyMoral

            storyFileLink = "https://storybucket.s3.amazonaws.com/{}".format(storyFileName)
            storyVO.storyFileLink = storyFileLink

            storyImageLink = "https://scfkiimagebucket.s3.amazonaws.com/story/{}".format(storyImageName)
            storyVO.storyImageLink = storyImageLink

            storyDAO.insertStory(storyVO)

            s3Resource = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)

            s3Resource.meta.client.upload_file(Filename=storyFilePath + storyFileName, Bucket="storybucket",
                                               Key=storyFileName, ExtraArgs={'ACL': 'public-read'})
            s3Resource.meta.client.upload_file(Filename=storyImagePath + storyImageName, Bucket="scfkiimagebucket",
                                               Key='story/{}'.format(storyImageName), ExtraArgs={'ACL': 'public-read'})

            return redirect(url_for("adminViewStory"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/viewStory", methods=['GET'])
def adminViewStory():
    try:
        if adminLoginSession() == "admin":
            storyDAO = StoryDAO()
            storyVOList = storyDAO.viewStory()
            return render_template("admin/viewStory.html", storyVOList=storyVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/deleteStory")
def adminDeleteStory():
    try:
        if adminLoginSession() == "admin":
            storyDAO = StoryDAO()
            storyVO = StoryVO()
            storyId = request.args.get("storyId")
            storyVO.storyId = storyId
            storyList = storyDAO.deleteStory(storyVO)

            storyFile = storyList.storyFilePath + storyList.storyFileName
            os.remove(storyFile.replace("../..", "../scfki/project"))

            storyImage = storyList.storyImagePath + storyList.storyImageName
            os.remove(storyImage.replace("../..", "../scfki/project"))

            s3 = boto3.resource("s3", aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
            obj = s3.Object("storybucket", storyList.storyFileName)
            obj.delete()
            obj = s3.Object("scfkiimagebucket", 'story/{}'.format(storyList.storyImageName))
            obj.delete()

            return redirect(url_for("adminViewStory"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/editStory")
def adminEditStory():
    try:
        if adminLoginSession() == "admin":
            storyDAO = StoryDAO()
            storyVO = StoryVO()
            storyTypeDAO = StoryTypeDAO()
            storyId = request.args.get("storyId")
            storyVO.storyId = storyId
            storyVOList = storyDAO.editStory(storyVO)
            storyTypeList = storyTypeDAO.viewStoryType()
            return render_template("admin/editStory.html", storyVOList=storyVOList, storyTypeList=storyTypeList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/updateStory", methods=['POST'])
def adminUpdateStory():
    try:
        if adminLoginSession() == "admin":
            story_StoryTypeId = request.form['story_StoryTypeId']
            storyId = request.form['storyId']
            storyTitle = request.form['storyTitle']
            storyMoral = request.form['storyMoral']

            storyVO = StoryVO()
            storyDAO = StoryDAO()

            storyVO.story_StoryTypeId = story_StoryTypeId
            storyVO.storyId = storyId
            storyVO.storyTitle = storyTitle
            storyVO.storyMoral = storyMoral

            storyDAO.updateStory(storyVO)
            return redirect(url_for("adminViewStory"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
