import os

import boto3
from flask import render_template, url_for, request, redirect
from werkzeug.utils import secure_filename

from project import app, ACCESS_KEY, SECRET_KEY
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.FactDAO import FactDAO
from project.com.dao.FactTypeDAO import FactTypeDAO
from project.com.vo.FactVO import FactVO


@app.route("/admin/loadFact")
def adminLoadFact():
    try:
        if adminLoginSession() == "admin":
            factTypeDAO = FactTypeDAO()
            factTypeList = factTypeDAO.viewFactType()
            return render_template("admin/addFact.html", factTypeList=factTypeList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/insertFact", methods=['POST', 'GET'])
def adminInsertFact():
    try:
        if adminLoginSession() == "admin":

            UPLOAD_FOLDER = "../scfki/project/static/adminResources/Fact/"
            app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

            fact = request.form['fact']
            factImage = request.files['factImage']
            fact_FactTypeId = request.form['fact_FactTypeId']

            factImageName = secure_filename(factImage.filename)
            factImagePath = os.path.join(app.config['UPLOAD_FOLDER'])
            factImage.save(os.path.join(factImagePath, factImageName))

            factVO = FactVO()
            factDAO = FactDAO()

            factVO.fact_FactTypeId = fact_FactTypeId
            factVO.fact = fact
            factVO.factImageName = factImageName
            factVO.factImagePath = factImagePath.replace("scfki/project", "..")

            factImageLink = "https://scfkiimagebucket.s3.amazonaws.com/fact/{}".format(factImageName)
            factVO.factImageLink = factImageLink

            factDAO.insertFact(factVO)

            s3Resource = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)

            s3Resource.meta.client.upload_file(Filename=factImagePath + factImageName, Bucket="scfkiimagebucket",
                                               Key='fact/{}'.format(factImageName), ExtraArgs={'ACL': 'public-read'})

            return redirect(url_for("adminViewFact"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/viewFact", methods=['GET'])
def adminViewFact():
    try:
        if adminLoginSession() == "admin":
            factDAO = FactDAO()
            factVOList = factDAO.viewFact()

            return render_template("admin/viewFact.html", factVOList=factVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/deleteFact")
def adminDeleteFact():
    try:
        if adminLoginSession() == "admin":
            factDAO = FactDAO()
            factVO = FactVO()
            factId = request.args.get("factId")
            factVO.factId = factId
            factList = factDAO.deleteFact(factVO)

            factImage = factList.factImagePath + factList.factImageName
            os.remove(factImage.replace("../..", "../scfki/project"))

            s3 = boto3.resource("s3", aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
            obj = s3.Object("scfkiimagebucket", 'fact/{}'.format(factList.factImageName))
            obj.delete()

            return redirect(url_for("adminViewFact"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/editFact")
def adminEditFact():
    try:
        if adminLoginSession() == "admin":
            factDAO = FactDAO()
            factVO = FactVO()
            factTypeDAO = FactTypeDAO()
            factId = request.args.get("factId")
            factVO.factId = factId
            factVOList = factDAO.editFact(factVO)
            factTypeList = factTypeDAO.viewFactType()
            return render_template("admin/editFact.html", factVOList=factVOList, factTypeList=factTypeList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/updateFact", methods=['POST'])
def adminUpdateFact():
    try:
        if adminLoginSession() == "admin":
            fact_FactTypeId = request.form['fact_FactTypeId']
            factId = request.form['factId']
            fact = request.form['fact']

            factVO = FactVO()
            factDAO = FactDAO()

            factVO.fact_FactTypeId = fact_FactTypeId
            factVO.factId = factId
            factVO.fact = fact

            factDAO.updateFact(factVO)
            return redirect(url_for("adminViewFact"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
