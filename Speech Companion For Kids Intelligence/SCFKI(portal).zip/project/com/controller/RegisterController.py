import random
import smtplib
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from flask import render_template, redirect, url_for, request, session

from project import app
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.LoginDAO import LoginDAO
from project.com.dao.RegisterDAO import RegisterDAO
from project.com.vo.LoginVO import LoginVO
from project.com.vo.RegisterVO import RegisterVO


@app.route("/user/loadRegister")
def userLoadRegister():
    try:
        return render_template("user/register.html")
    except Exception as ex:
        print(ex)


@app.route("/user/insertRegister", methods=['POST'])
def userInsertRegister():
    try:
        loginUsername = request.form['loginUsername']
        loginPassword = ''.join((random.choice(string.ascii_letters + string.digits)) for x in range(8))

        loginVO = LoginVO()
        loginDAO = LoginDAO()

        loginVO.loginUsername = loginUsername
        loginVO.loginPassword = loginPassword
        loginVO.loginRole = "user"
        loginVO.loginStatus = "active"

        if len([i.as_dict() for i in loginDAO.validateLoginUsername(loginVO)]) == 0:
            sender = "scki.alexa@gmail.com"
            receiver = loginUsername
            msg = MIMEMultipart()
            msg['From'] = sender
            msg['To'] = receiver
            msg['subject'] = "ACCOUNT PASSWORD"
            msg.attach(
                MIMEText('Welcome to our Alexa based application!!! Thank you for joining us!!! Your Password is:'))
            msg.attach(MIMEText(loginPassword, 'plain'))
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(sender, "42734599")
            text = msg.as_string()
            server.sendmail(sender, receiver, text)

            loginDAO.insertLogin(loginVO)

            registerChildName = request.form['registerChildName']
            registerChildBirthDate = request.form['registerChildBirthDate']
            registerChildGender = request.form['registerChildGender']
            registerParentName = request.form['registerParentName']
            registerContact = request.form['registerContact']
            registerAddress = request.form['registerAddress']

            registerVO = RegisterVO()
            registerDAO = RegisterDAO()

            registerVO.registerChildName = registerChildName
            registerVO.registerChildBirthDate = registerChildBirthDate
            registerVO.registerChildGender = registerChildGender
            registerVO.registerParentName = registerParentName
            registerVO.registerContact = registerContact
            registerVO.registerAddress = registerAddress
            registerVO.register_LoginId = loginVO.loginId

            registerDAO.insertRegister(registerVO)

            server.quit()
            return render_template("admin/login.html")
        else:
            msg = "This E-mail is already registered !"
            return render_template("admin/login.html", error=msg)
    except Exception as ex:
        print(ex)


@app.route('/admin/viewRegister')
def adminViewRegister():
    try:
        if adminLoginSession() == "admin":
            registerDAO = RegisterDAO()
            registerVOList = registerDAO.viewRegister()
            return render_template("admin/viewUser.html", registerVOList=registerVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/admin/blockRegister')
def adminBlockRegister():
    try:
        if adminLoginSession() == "admin":
            registerDAO = RegisterDAO()
            loginVO = LoginVO()

            loginId = request.args.get("loginId")
            print("ID", loginId)
            loginVO.loginId = loginId
            loginVO.loginStatus = 'inactive'

            registerDAO.blockRegister(loginVO)
            return redirect(url_for('adminViewRegister'))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/admin/unblockRegister')
def adminUnblockRegister():
    try:
        if adminLoginSession() == "admin":
            registerDAO = RegisterDAO()
            loginVO = LoginVO()

            loginId = request.args.get("loginId")

            loginVO.loginId = loginId
            loginVO.loginStatus = 'active'

            registerDAO.unblockRegister(loginVO)
            return redirect(url_for('adminViewRegister'))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/user/editProfile')
def userEditProfile():
    try:
        if adminLoginSession() == "user":
            loginId = session['session_loginId']

            registerVO = RegisterVO()
            registerDAO = RegisterDAO()
            loginDAO = LoginDAO()

            loginVOList = loginDAO.fetchUsername(loginId)

            registerVO.register_LoginId = loginId

            registerVOList = registerDAO.editRegister(registerVO)
            return render_template("user/editProfile.html", registerVOList=registerVOList, loginVOList=loginVOList)

        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/user/updateProfile', methods=['POST'])
def userUpdateProfile():
    try:
        if adminLoginSession() == "user":
            registerId = request.form['registerId']
            loginId = request.form['loginId']

            loginUsername = request.form['loginUsername']

            loginVO = LoginVO()
            loginDAO = LoginDAO()

            loginVO.loginId = loginId
            loginVO.loginUsername = loginUsername

            if session['session_loginUsername'] != loginUsername:
                if len([i.as_dict() for i in loginDAO.validateLoginUsername(loginVO)]) == 0:
                    loginPassword = ''.join((random.choice(string.ascii_letters + string.digits)) for x in range(8))
                    sender = "scki.alexa@gmail.com"
                    receiver = loginUsername
                    msg = MIMEMultipart()
                    msg['From'] = sender
                    msg['To'] = receiver
                    msg['subject'] = "ACCOUNT PASSWORD"
                    msg.attach(
                        MIMEText(
                            'Welcome to our Alexa based application!!! Thank you for joining us!!! Your Password is:'))
                    msg.attach(MIMEText(loginPassword, 'plain'))
                    server = smtplib.SMTP('smtp.gmail.com', 587)
                    server.starttls()
                    server.login(sender, "42734599")
                    text = msg.as_string()
                    server.sendmail(sender, receiver, text)
                    server.quit()
                    loginVO.loginId = loginId
                    loginVO.loginUsername = loginUsername
                    loginVO.loginPassword = loginPassword
                    loginDAO.updateLogin(loginVO)
                else:
                    return render_template('user/editProfile.html', error="Given Username is already registered!")
            else:
                pass
            registerChildName = request.form['registerChildName']
            registerChildBirthDate = request.form['registerChildBirthDate']
            registerChildGender = request.form['registerChildGender']
            registerParentName = request.form['registerParentName']
            registerContact = request.form['registerContact']
            registerAddress = request.form['registerAddress']

            registerVO = RegisterVO()
            registerDAO = RegisterDAO()

            registerVO.registerId = registerId
            registerVO.registerChildName = registerChildName
            registerVO.registerChildBirthDate = registerChildBirthDate
            registerVO.registerChildGender = registerChildGender
            registerVO.registerParentName = registerParentName
            registerVO.registerContact = registerContact
            registerVO.registerAddress = registerAddress
            registerVO.register_LoginId = loginVO.loginId

            registerDAO.updateRegister(registerVO)
            return render_template('user/dashboard.html')
        else:
            return redirect(url_for("adminLogoutSession"))

    except Exception as ex:
        print(ex)
