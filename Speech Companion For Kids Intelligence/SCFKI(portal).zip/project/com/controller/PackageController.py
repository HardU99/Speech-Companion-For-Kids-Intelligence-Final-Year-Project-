from flask import request, render_template, redirect, url_for

from project import app
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.PackageDAO import PackageDAO
from project.com.dao.PurchaseDAO import PurchaseDAO
from project.com.vo.PackageVO import PackageVO


# Admin Side

@app.route('/admin/loadPackage', methods=['GET'])
def adminLoadPackage():
    try:
        if adminLoginSession() == "admin":
            return render_template("admin/addPackage.html")
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/admin/insertPackage', methods=['GET', 'POST'])
def adminInsertPackage():
    try:
        if adminLoginSession() == "admin":
            packageName = request.form['packageName']
            packageDescription = request.form['packageDescription']
            packageDuration = request.form['packageDuration']
            packagePrice = request.form['packagePrice']

            packageVO = PackageVO()
            packageDAO = PackageDAO()

            packageVO.packageName = packageName
            packageVO.packageDescription = packageDescription
            packageVO.packageDuration = packageDuration
            packageVO.packagePrice = packagePrice

            packageDAO.insertPackage(packageVO)
            return redirect(url_for("adminViewPackage"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        return print(ex)


@app.route('/admin/viewPackage', methods=['GET'])
def adminViewPackage():
    try:
        if adminLoginSession() == "admin":
            packageDAO = PackageDAO()
            packageVOList = packageDAO.viewPackage()
            return render_template('admin/viewPackage.html', packageVOList=packageVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/admin/deletePackage', methods=['GET'])
def adminDeletePackage():
    try:
        if adminLoginSession() == "admin":
            packageVO = PackageVO()
            packageDAO = PackageDAO()
            packageId = request.args.get('packageId')
            packageVO.packageId = packageId
            packageDAO.deletePackage(packageVO)
            return redirect(url_for('adminViewPackage'))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/admin/editPackage', methods=['GET'])
def adminEditPackage():
    try:
        if adminLoginSession() == "admin":
            packageVO = PackageVO()
            packageDAO = PackageDAO()
            packageId = request.args.get('packageId')
            packageVO.packageId = packageId
            packageVOList = packageDAO.editPackage(packageVO)
            return render_template('admin/editPackage.html', packageVOList=packageVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/admin/updatePackage', methods=['GET', 'POST'])
def adminUpdatePackage():
    try:
        if adminLoginSession() == "admin":
            packageId = request.form['packageId']
            packageName = request.form['packageName']
            packageDescription = request.form['packageDescription']
            packageDuration = request.form['packageDuration']
            packagePrice = request.form['packagePrice']

            packageVO = PackageVO()
            packageDAO = PackageDAO()

            packageVO.packageId = packageId
            packageVO.packageName = packageName
            packageVO.packageDescription = packageDescription
            packageVO.packageDuration = packageDuration
            packageVO.packagePrice = packagePrice

            packageDAO.updatePackage(packageVO)

            return redirect(url_for('adminViewPackage'))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


# User Side

@app.route('/user/viewPackage', methods=['GET'])
def userViewPackage():
    try:
        if adminLoginSession() == "user":
            packageDAO = PackageDAO()
            purchaseDAO = PurchaseDAO()

            purchasedPackageList = [i.as_dict() for i in purchaseDAO.viewPurchasedPackage()]
            packageVOList = [i.as_dict() for i in packageDAO.viewPackage()]

            for j in range(len(purchasedPackageList)):
                for i in range(len(packageVOList)):
                    try:
                        if packageVOList[i]['packageId'] == purchasedPackageList[j]['purchase_PackageId']:
                            del packageVOList[i]
                    except:
                        continue
            return render_template('user/viewPackage.html', packageVOList=packageVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
