from datetime import datetime, date

from flask import render_template, url_for, redirect, request, session

from project import app
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.FeedbackDAO import FeedbackDAO
from project.com.vo.FeedbackVO import FeedbackVO


@app.route("/user/loadFeedback")
def userLoadFeedback():
    try:
        if adminLoginSession() == "user":
            return render_template('user/addFeedback.html')
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/user/insertFeedback", methods=['GET', 'POST'])
def userInsertFeedback():
    try:
        if adminLoginSession() == "user":
            time = datetime.now()

            feedbackSubject = request.form['feedbackSubject']
            feedbackDescription = request.form['feedbackDescription']
            feedbackRating = request.form['feedbackRating']

            feedbackVO = FeedbackVO()
            feedbackDAO = FeedbackDAO()

            feedbackVO.feedbackSubject = feedbackSubject
            feedbackVO.feedbackDescription = feedbackDescription
            feedbackVO.feedbackRating = feedbackRating
            feedbackVO.feedbackDate = date.today()
            feedbackVO.feedbackTime = time.strftime("%H:%M:%S")
            feedbackVO.feedbackFrom_LoginId = session['session_loginId']

            feedbackDAO.insertFeedback(feedbackVO)

            return redirect(url_for("userViewFeedback"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/user/viewFeedback", methods=['GET'])
def userViewFeedback():
    try:
        if adminLoginSession() == 'user':
            feedbackDAO = FeedbackDAO()
            feedbackVOList = feedbackDAO.viewFeedback()
            return render_template("user/viewFeedback.html", feedbackVOList=feedbackVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/user/deleteFeedback")
def userDeleteFeedback():
    try:
        if adminLoginSession() == "user":
            feedbackDAO = FeedbackDAO()
            feedbackVO = FeedbackVO()

            feedbackId = request.args.get("feedbackId")

            feedbackVO.feedbackId = feedbackId
            feedbackDAO.deleteFeedback(feedbackVO)

            return redirect(url_for("userViewFeedback"))
        else:
            return redirect(url_for("adminLogoutSession"))

    except Exception as ex:
        print(ex)


@app.route('/admin/viewFeedback')
def adminViewFeedback():
    try:
        if adminLoginSession() == "admin":
            feedbackDAO = FeedbackDAO()
            FeedbackVOList = feedbackDAO.viewFeedback()
            return render_template("admin/viewFeedback.html", FeedbackVOList=FeedbackVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/deleteFeedback")
def adminDeleteFeedback():
    try:
        if adminLoginSession() == "user":
            feedbackDAO = FeedbackDAO()
            feedbackVO = FeedbackVO()

            feedbackId = request.args.get("feedbackId")

            feedbackVO.feedbackId = feedbackId
            feedbackDAO.deleteFeedback(feedbackVO)

            return redirect(url_for("adminViewFeedback"))
        else:
            return redirect(url_for("adminLogoutSession"))

    except Exception as ex:
        print(ex)


@app.route('/admin/reviewFeedback')
def adminReviewFeedback():
    try:
        feedbackId = request.args.get("feedbackId")

        feedbackVO = FeedbackVO()
        feedbackDAO = FeedbackDAO()

        feedbackTo_LoginId = session['session_loginId']
        feedbackVO.feedbackTo_LoginId = feedbackTo_LoginId
        feedbackVO.feedbackId = feedbackId

        feedbackDAO.addReviewId(feedbackVO)
        return redirect(url_for('adminViewFeedback'))
    except Exception as ex:
        print(ex)
