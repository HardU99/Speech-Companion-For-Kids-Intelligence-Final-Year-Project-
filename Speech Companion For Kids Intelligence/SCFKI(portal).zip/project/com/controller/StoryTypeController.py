import os

import boto3
from flask import render_template, url_for, request, redirect
from werkzeug.utils import secure_filename

from project import app, ACCESS_KEY, SECRET_KEY
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.StoryTypeDAO import StoryTypeDAO
from project.com.vo.StoryTypeVO import StoryTypeVO


@app.route("/admin/loadStoryType")
def adminLoadStoryType():
    try:
        if adminLoginSession() == "admin":
            return render_template("admin/addStoryType.html")
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/insertStoryType", methods=['POST'])
def adminInsertStoryType():
    try:
        if adminLoginSession() == "admin":
            UPLOAD_FOLDER = "../scfki/project/static/adminResources/StoryType/"
            app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

            storyType = request.form['storyType']
            storyTypeDescription = request.form['storyTypeDescription']
            storyTypeImage = request.files['storyTypeImage']

            storyTypeVO = StoryTypeVO()
            storyTypeDAO = StoryTypeDAO()

            storyTypeImageName = secure_filename(storyTypeImage.filename)
            storyTypeImagePath = os.path.join(app.config['UPLOAD_FOLDER'])
            storyTypeImage.save(os.path.join(storyTypeImagePath, storyTypeImageName))

            storyTypeVO.storyType = storyType
            storyTypeVO.storyTypeDescription = storyTypeDescription
            storyTypeVO.storyTypeImageName = storyTypeImageName
            storyTypeVO.storyTypeImagePath = storyTypeImagePath.replace("scfki/project", "..")
            storyTypeImageLink = "https://scfkiimagebucket.s3.amazonaws.com/storytype/{}".format(storyTypeImageName)
            storyTypeVO.storyTypeImageLink = storyTypeImageLink

            storyTypeDAO.insertStoryType(storyTypeVO)

            s3Resource = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
            s3Resource.meta.client.upload_file(Filename=storyTypeImagePath + storyTypeImageName,
                                               Bucket="scfkiimagebucket",
                                               Key='storytype/{}'.format(storyTypeImageName),
                                               ExtraArgs={'ACL': 'public-read'})

            return redirect(url_for("adminViewStoryType"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/viewStoryType", methods=['GET'])
def adminViewStoryType():
    try:
        if adminLoginSession() == "admin":
            storyTypeDAO = StoryTypeDAO()
            storyTypeVOList = storyTypeDAO.viewStoryType()
            return render_template("admin/viewStoryType.html", storyTypeVOList=storyTypeVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/deleteStoryType")
def adminDeleteStoryType():
    try:
        if adminLoginSession() == "admin":
            storyTypeDAO = StoryTypeDAO()
            storyTypeVO = StoryTypeVO()
            storyTypeId = request.args.get("storyTypeId")
            storyTypeVO.storyTypeId = storyTypeId
            storyTypeList = storyTypeDAO.deleteStoryType(storyTypeVO)
            storyTypeImage = storyTypeList.storyTypeImagePath + storyTypeList.storyTypeImageName
            os.remove(storyTypeImage.replace("../..", "../scfki/project"))
            s3 = boto3.resource("s3", aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
            obj = s3.Object("scfkiimagebucket", 'storytype/{}'.format(storyTypeList.storyTypeImageName))
            obj.delete()

            return redirect(url_for("adminViewStoryType"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/editStoryType")
def adminEditStoryType():
    try:
        if adminLoginSession() == "admin":
            storyTypeDAO = StoryTypeDAO()
            storyTypeVO = StoryTypeVO()
            storyTypeId = request.args.get("storyTypeId")
            storyTypeVO.storyTypeId = storyTypeId
            storyTypeVOList = storyTypeDAO.editStoryType(storyTypeVO)
            return render_template("admin/editStoryType.html", storyTypeVOList=storyTypeVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/updateStoryType", methods=['POST'])
def adminUpdateStoryType():
    try:
        if adminLoginSession() == "admin":
            storyTypeId = request.form["storyTypeId"]
            storyType = request.form['storyType']
            storyTypeDescription = request.form['storyTypeDescription']

            storyTypeVO = StoryTypeVO()
            storyTypeDAO = StoryTypeDAO()

            storyTypeVO.storyTypeId = storyTypeId
            storyTypeVO.storyType = storyType
            storyTypeVO.storyTypeDescription = storyTypeDescription

            storyTypeDAO.updateStoryType(storyTypeVO)

            return redirect(url_for("adminViewStoryType"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
