from flask import render_template, url_for, request, redirect

from project import app
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.MathQuizDAO import MathQuizDAO
from project.com.vo.MathQuizVO import MathQuizVO


@app.route("/admin/loadMathQuiz")
def adminLoadMathQuiz():
    try:
        if adminLoginSession() == "admin":
            return render_template("admin/addMathQuiz.html")
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/insertMathQuiz", methods=['POST'])
def adminInsertMathQuiz():
    try:
        if adminLoginSession() == "admin":
            mathQuizQuestion = request.form['mathQuizQuestion']
            mathQuizAnswer = request.form['mathQuizAnswer']

            mathQuizVO = MathQuizVO()
            mathQuizDAO = MathQuizDAO()

            mathQuizVO.mathQuizQuestion = mathQuizQuestion
            mathQuizVO.mathQuizAnswer = mathQuizAnswer

            mathQuizDAO.insertMathQuiz(mathQuizVO)

            return redirect(url_for("adminViewMathQuiz"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/viewMathQuiz", methods=['GET'])
def adminViewMathQuiz():
    try:
        if adminLoginSession() == "admin":
            mathQuizDAO = MathQuizDAO()
            mathQuizVOList = mathQuizDAO.viewMathQuiz()
            return render_template("admin/viewMathQuiz.html", mathQuizVOList=mathQuizVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/deleteMathQuiz")
def adminDeleteMathQuiz():
    try:
        if adminLoginSession() == "admin":
            mathQuizDAO = MathQuizDAO()
            mathQuizVO = MathQuizVO()
            
            mathQuizId = request.args.get("mathQuizId")
            
            mathQuizVO.mathQuizId = mathQuizId
            mathQuizDAO.deleteMathQuiz(mathQuizVO)
            return redirect(url_for("adminViewMathQuiz"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/editMathQuiz")
def adminEditMathQuiz():
    try:
        if adminLoginSession() == "admin":
            mathQuizDAO = MathQuizDAO()
            mathQuizVO = MathQuizVO()
            
            mathQuizId = request.args.get("mathQuizId")
            
            mathQuizVO.mathQuizId = mathQuizId
            mathQuizVOList = mathQuizDAO.editMathQuiz(mathQuizVO)
            
            return render_template("admin/editMathQuiz.html", mathQuizVOList=mathQuizVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/updateMathQuiz", methods=['POST'])
def adminUpdateMathQuiz():
    try:
        if adminLoginSession() == "admin":
            mathQuizId = request.form['mathQuizId']
            mathQuizQuestion = request.form['mathQuizQuestion']
            mathQuizAnswer = request.form['mathQuizAnswer']

            mathQuizVO = MathQuizVO()
            mathQuizDAO = MathQuizDAO()

            mathQuizVO.mathQuizQuestion = mathQuizQuestion
            mathQuizVO.mathQuizAnswer = mathQuizAnswer
            mathQuizVO.mathQuizId = mathQuizId

            mathQuizDAO.updateMathQuiz(mathQuizVO)

            return redirect(url_for("adminViewMathQuiz"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
