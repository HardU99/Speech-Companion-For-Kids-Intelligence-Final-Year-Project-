from flask import render_template, redirect, url_for, request, session

from project import app
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.TestDAO import TestDAO

# Admin Side
from project.com.vo.TestVO import TestVO


@app.route('/admin/viewTest')
def adminViewTest():
    try:
        if adminLoginSession() == "admin":
            testDAO = TestDAO()
            testVOList = testDAO.adminViewTest()
            return render_template("admin/viewTest.html", testVOList=testVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/admin/deleteTest', methods=['GET'])
def adminDeleteTest():
    try:
        if adminLoginSession() == "admin":
            testVO = TestVO()
            testDAO = TestDAO()
            testId = request.args.get('testId')
            testVO.testId = testId
            testDAO.deleteTest(testVO)
            return redirect(url_for('adminViewPackage'))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


# User Side

@app.route('/user/viewTest')
def userViewTest():
    try:
        if adminLoginSession() == "user":
            testDAO = TestDAO()
            testVOList = testDAO.userViewTest()
            return render_template("user/viewTest.html", testVOList=testVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
