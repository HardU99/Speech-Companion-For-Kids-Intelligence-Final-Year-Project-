import os
from datetime import datetime, date

from flask import render_template, redirect, url_for, request, session
from werkzeug.utils import secure_filename

from project import app
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.ComplainDAO import ComplainDAO
from project.com.vo.ComplainVO import ComplainVO


# Admin Side

@app.route('/admin/viewComplain')
def adminViewComplain():
    try:
        if adminLoginSession() == "admin":
            complainDAO = ComplainDAO()
            complainVOList = complainDAO.viewComplain()
            return render_template("admin/viewComplain.html", complainVOList=complainVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/loadComplainReply")
def adminLoadComplainReply():
    try:
        if adminLoginSession() == "admin":
            complainVO = ComplainVO()
            complainId = request.args.get("complainId")
            complainVO.complainId = complainId
            return render_template('admin/addComplainReply.html', complainId=complainVO.complainId)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/insertComplainReply", methods=['GET', 'POST'])
def adminInsertComplainReply():
    try:
        if adminLoginSession() == "admin":
            time = datetime.now()

            UPLOAD_FOLDER = "../scfki/project/static/adminResources/complain/"
            app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

            complainId = request.form['complainId']
            replySubject = request.form['replySubject']
            replyMessage = request.form['replyMessage']
            replyFile = request.files['replyFile']
            replyFileName = secure_filename(replyFile.filename)

            replyFilePath = os.path.join(app.config['UPLOAD_FOLDER'])

            replyFile.save(os.path.join(replyFilePath, replyFileName))

            complainVO = ComplainVO()
            complainDAO = ComplainDAO()

            complainVO.complainId = complainId
            complainVO.replySubject = replySubject
            complainVO.replyMessage = replyMessage
            complainVO.replyDate = date.today()
            complainVO.replyTime = time.strftime("%H:%M:%S")
            complainVO.replyFileName = replyFileName
            complainVO.replyFilePath = replyFilePath.replace("scfki/project", "..")
            complainVO.complainStatus = 'replied'
            complainVO.complainTo_LoginId = session['session_loginId']

            complainDAO.insertComplainReply(complainVO)

            return redirect('/admin/viewComplainReply?complainId={}'.format(complainVO.complainId))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/viewComplainReply")
def adminViewComplainReply():
    try:
        if adminLoginSession() == "admin":
            complainVO = ComplainVO()
            complainDAO = ComplainDAO()

            complainId = request.args.get("complainId")

            complainVO.complainId = complainId

            complainReplyList = complainDAO.viewComplainReply(complainVO)
            return render_template("admin/viewComplainReply.html", complainReplyList=complainReplyList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


# User side

@app.route("/user/loadComplain")
def userLoadComplain():
    try:
        if adminLoginSession() == "user":
            return render_template('user/addComplain.html')
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/user/insertComplain", methods=['GET', 'POST'])
def userInsertComplain():
    try:
        if adminLoginSession() == "user":
            time = datetime.now()

            UPLOAD_FOLDER = "../scfki/project/static/adminResources/complain/"
            app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

            complainSubject = request.form['complainSubject']
            complainDescription = request.form['complainDescription']
            complainFile = request.files['complainFile']

            complainFileName = secure_filename(complainFile.filename)

            complainFilePath = os.path.join(app.config['UPLOAD_FOLDER'])

            complainFile.save(os.path.join(complainFilePath, complainFileName))

            complainVO = ComplainVO()
            complainDAO = ComplainDAO()

            complainVO.complainSubject = complainSubject
            complainVO.complainDescription = complainDescription
            complainVO.complainDate = date.today()
            complainVO.complainTime = time.strftime("%H:%M:%S")
            complainVO.complainStatus = "pending"
            complainVO.complainFileName = complainFileName
            complainVO.complainFilePath = complainFilePath.replace("scfki/project", "..")
            complainVO.complainFrom_LoginId = session['session_loginId']

            complainDAO.insertComplain(complainVO)

            return redirect(url_for("userViewComplain"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/user/viewComplain", methods=['GET'])
def userViewComplain():
    try:
        if adminLoginSession() == 'user':
            complainDAO = ComplainDAO()
            complainVOList = complainDAO.viewComplain()
            return render_template("user/viewComplain.html", complainVOList=complainVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/user/deleteComplain")
def userDeleteComplain():
    try:
        if adminLoginSession() == "user":
            complainDAO = ComplainDAO()
            complainVO = ComplainVO()

            complainId = request.args.get("complainId")

            complainVO.complainId = complainId
            complainList = complainDAO.deleteComplain(complainVO)

            complainFile = complainList.complainFilePath + complainList.complainFileName

            os.remove(complainFile.replace("../..", "../scfki/project"))
            if complainList.replyFileName != None:
                replyFile = complainList.replyFilePath + complainList.replyFileName
                os.remove(replyFile.replace("../..", "../scfki/project"))

            return redirect(url_for("userViewComplain"))
        else:
            return redirect(url_for("adminLogoutSession"))

    except Exception as ex:
        print(ex)


@app.route("/user/viewComplainReply")
def userViewComplainReply():
    try:
        if adminLoginSession() == "user":
            complainVO = ComplainVO()
            complainDAO = ComplainDAO()

            complainId = request.args.get("complainId")

            complainVO.complainId = complainId

            complainReplyList = complainDAO.viewComplainReply(complainVO)
            return render_template("user/viewComplainReply.html", complainReplyList=complainReplyList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
