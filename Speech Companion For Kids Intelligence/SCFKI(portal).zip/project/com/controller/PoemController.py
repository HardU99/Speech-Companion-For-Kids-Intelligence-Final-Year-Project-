import os

import boto3
from flask import render_template, url_for, request, redirect
from werkzeug.utils import secure_filename

from project import app, ACCESS_KEY, SECRET_KEY
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.PoemDAO import PoemDAO
from project.com.vo.PoemVO import PoemVO


@app.route("/admin/loadPoem")
def adminLoadPoem():
    try:
        if adminLoginSession() == "admin":
            return render_template("admin/addPoem.html")
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/insertPoem", methods=['POST', 'GET'])
def adminInsertPoem():
    try:
        if adminLoginSession() == "admin":

            UPLOAD_FOLDER = "../scfki/project/static/adminResources/Poem/"
            app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

            poemTitle = request.form['poemTitle']
            poemFile = request.files['poemFile']
            poemImage = request.files['poemImage']

            poemFileName = secure_filename(poemFile.filename)
            poemFilePath = os.path.join(app.config['UPLOAD_FOLDER'])
            poemFile.save(os.path.join(poemFilePath, poemFileName))

            poemImageName = secure_filename(poemImage.filename)
            poemImagePath = os.path.join(app.config['UPLOAD_FOLDER'])
            poemImage.save(os.path.join(poemImagePath, poemImageName))

            poemVO = PoemVO()
            poemDAO = PoemDAO()

            poemVO.poemTitle = poemTitle
            poemVO.poemFileName = poemFileName
            poemVO.poemFilePath = poemFilePath.replace("scfki/project", "..")
            poemVO.poemImageName = poemImageName
            poemVO.poemImagePath = poemImagePath.replace("scfki/project", "..")

            poemFileLink = "https://poembucket.s3.amazonaws.com/{}".format(poemFileName)
            poemVO.poemFileLink = poemFileLink
            poemImageLink = "https://scfkiimagebucket.s3.amazonaws.com/poem/{}".format(poemImageName)
            poemVO.poemImageLink = poemImageLink

            poemDAO.insertPoem(poemVO)

            s3Resource = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)

            s3Resource.meta.client.upload_file(Filename=poemFilePath + poemFileName, Bucket="poembucket",
                                               Key=poemFileName, ExtraArgs={'ACL': 'public-read'})
            s3Resource.meta.client.upload_file(Filename=poemImagePath + poemImageName, Bucket="scfkiimagebucket",
                                               Key='poem/{}'.format(poemImageName), ExtraArgs={'ACL': 'public-read'})

            return redirect(url_for("adminViewPoem"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/viewPoem", methods=['GET'])
def adminViewPoem():
    try:
        if adminLoginSession() == "admin":
            poemDAO = PoemDAO()
            poemVOList = poemDAO.viewPoem()
            return render_template("admin/viewPoem.html", poemVOList=poemVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/deletePoem")
def adminDeletePoem():
    try:
        if adminLoginSession() == "admin":
            poemDAO = PoemDAO()
            poemVO = PoemVO()
            poemId = request.args.get("poemId")
            poemVO.poemId = poemId
            poemList = poemDAO.deletePoem(poemVO)

            poemFile = poemList.poemFilePath + poemList.poemFileName
            os.remove(poemFile.replace("../..", "../scfki/project"))

            poemImage = poemList.poemImagePath + poemList.poemImageName
            os.remove(poemImage.replace("../..", "../scfki/project"))

            s3 = boto3.resource("s3", aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
            obj = s3.Object("poembucket", poemList.poemFileName)
            obj.delete()
            obj = s3.Object("scfkiimagebucket", 'poem/{}'.format(poemList.poemImageName))
            obj.delete()

            return redirect(url_for("adminViewPoem"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/editPoem")
def adminEditPoem():
    try:
        if adminLoginSession() == "admin":
            poemDAO = PoemDAO()
            poemVO = PoemVO()
            poemId = request.args.get("poemId")
            poemVO.poemId = poemId
            poemVOList = poemDAO.editPoem(poemVO)
            return render_template("admin/editPoem.html", poemVOList=poemVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/updatePoem", methods=['POST'])
def adminUpdatePoem():
    try:
        if adminLoginSession() == "admin":
            poemId = request.form['poemId']
            poemTitle = request.form['poemTitle']

            poemVO = PoemVO()
            poemDAO = PoemDAO()

            poemVO.poemId = poemId
            poemVO.poemTitle = poemTitle

            poemDAO.updatePoem(poemVO)
            return redirect(url_for("adminViewPoem"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
