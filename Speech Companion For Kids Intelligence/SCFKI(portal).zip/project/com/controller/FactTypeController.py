import os

import boto3
from flask import render_template, url_for, request, redirect
from werkzeug.utils import secure_filename

from project import app, ACCESS_KEY, SECRET_KEY
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.FactTypeDAO import FactTypeDAO
from project.com.vo.FactTypeVO import FactTypeVO


@app.route("/admin/loadFactType")
def adminLoadFactType():
    try:
        if adminLoginSession() == "admin":
            return render_template("admin/addFactType.html")
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/insertFactType", methods=['POST'])
def adminInsertFactType():
    try:
        if adminLoginSession() == "admin":
            UPLOAD_FOLDER = "../scfki/project/static/adminResources/FactType/"
            app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

            factType = request.form['factType']
            factTypeDescription = request.form['factTypeDescription']
            factTypeImage = request.files['factTypeImage']

            factTypeVO = FactTypeVO()
            factTypeDAO = FactTypeDAO()

            factTypeImageName = secure_filename(factTypeImage.filename)
            factTypeImagePath = os.path.join(app.config['UPLOAD_FOLDER'])
            factTypeImage.save(os.path.join(factTypeImagePath, factTypeImageName))

            factTypeVO.factType = factType
            factTypeVO.factTypeDescription = factTypeDescription
            factTypeVO.factTypeImageName = factTypeImageName
            factTypeVO.factTypeImagePath = factTypeImagePath.replace("scfki/project", "..")
            factTypeImageLink = "https://scfkiimagebucket.s3.amazonaws.com/facttype/{}".format(factTypeImageName)
            factTypeVO.factTypeImageLink = factTypeImageLink

            factTypeDAO.insertFactType(factTypeVO)

            s3Resource = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
            s3Resource.meta.client.upload_file(Filename=factTypeImagePath + factTypeImageName,
                                               Bucket="scfkiimagebucket",
                                               Key='facttype/{}'.format(factTypeImageName),
                                               ExtraArgs={'ACL': 'public-read'})

            return redirect(url_for("adminViewFactType"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/viewFactType", methods=['GET'])
def adminViewFactType():
    try:
        if adminLoginSession() == "admin":
            factTypeDAO = FactTypeDAO()
            factTypeVOList = factTypeDAO.viewFactType()
            return render_template("admin/viewFactType.html", factTypeVOList=factTypeVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/deleteFactType")
def adminDeleteFactType():
    try:
        if adminLoginSession() == "admin":
            factTypeDAO = FactTypeDAO()
            factTypeVO = FactTypeVO()
            factTypeId = request.args.get("factTypeId")
            factTypeVO.factTypeId = factTypeId
            factTypeList = factTypeDAO.deleteFactType(factTypeVO)
            factTypeImage = factTypeList.factTypeImagePath + factTypeList.factTypeImageName
            os.remove(factTypeImage.replace("../..", "../scfki/project"))
            s3 = boto3.resource("s3", aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
            obj = s3.Object("scfkiimagebucket", 'facttype/{}'.format(factTypeList.factTypeImageName))
            obj.delete()

            return redirect(url_for("adminViewFactType"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/editFactType")
def adminEditFactType():
    try:
        if adminLoginSession() == "admin":
            factTypeDAO = FactTypeDAO()
            factTypeVO = FactTypeVO()
            factTypeId = request.args.get("factTypeId")
            factTypeVO.factTypeId = factTypeId
            factTypeVOList = factTypeDAO.editFactType(factTypeVO)
            return render_template("admin/editFactType.html", factTypeVOList=factTypeVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/updateFactType", methods=['POST'])
def adminUpdateFactType():
    try:
        if adminLoginSession() == "admin":
            factTypeId = request.form["factTypeId"]
            factType = request.form['factType']
            factTypeDescription = request.form['factTypeDescription']

            factTypeVO = FactTypeVO()
            factTypeDAO = FactTypeDAO()

            factTypeVO.factTypeId = factTypeId
            factTypeVO.factType = factType
            factTypeVO.factTypeDescription = factTypeDescription

            factTypeDAO.updateFactType(factTypeVO)

            return redirect(url_for("adminViewFactType"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
