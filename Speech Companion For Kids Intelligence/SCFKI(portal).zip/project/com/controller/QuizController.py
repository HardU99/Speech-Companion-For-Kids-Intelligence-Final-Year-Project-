from flask import render_template, url_for, request, redirect

from project import app
from project.com.controller.LoginController import adminLoginSession
from project.com.dao.QuizDAO import QuizDAO
from project.com.dao.StoryDAO import StoryDAO
from project.com.dao.StoryTypeDAO import StoryTypeDAO
from project.com.vo.QuizVO import QuizVO


@app.route("/admin/loadQuiz")
def adminLoadQuiz():
    try:
        if adminLoginSession() == "admin":
            storyTypeDAO = StoryTypeDAO()
            storyDAO = StoryDAO()

            storyTypeList = storyTypeDAO.viewStoryType()
            storyList = storyDAO.viewStory()
            return render_template("admin/addQuiz.html", storyTypeList=storyTypeList, storyList=storyList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/insertQuiz", methods=['POST'])
def adminInsertQuiz():
    try:
        if adminLoginSession() == "admin":
            quizQuestion = request.form['quizQuestion']
            quizAnswer = request.form['quizAnswer']
            quiz_StoryTypeId = request.form['quiz_StoryTypeId']
            quiz_StoryId = request.form['quiz_StoryId']

            quizVO = QuizVO()
            quizDAO = QuizDAO()

            quizVO.quiz_StoryTypeId = quiz_StoryTypeId
            quizVO.quiz_StoryId = quiz_StoryId
            quizVO.quizQuestion = quizQuestion
            quizVO.quizAnswer = quizAnswer

            quizDAO.insertQuiz(quizVO)

            return redirect(url_for("adminViewQuiz"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/viewQuiz", methods=['GET'])
def adminViewQuiz():
    try:
        if adminLoginSession() == "admin":
            quizDAO = QuizDAO()
            quizVOList = quizDAO.viewQuiz()
            return render_template("admin/viewQuiz.html", quizVOList=quizVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/deleteQuiz")
def adminDeleteQuiz():
    try:
        if adminLoginSession() == "admin":
            quizDAO = QuizDAO()
            quizVO = QuizVO()
            quizId = request.args.get("quizId")
            quizVO.quizId = quizId
            quizDAO.deleteQuiz(quizVO)
            return redirect(url_for("adminViewQuiz"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/editQuiz")
def adminEditQuiz():
    try:
        if adminLoginSession() == "admin":
            quizDAO = QuizDAO()
            quizVO = QuizVO()
            quizId = request.args.get("quizId")
            quizVO.quizId = quizId
            quizVOList = quizDAO.editQuiz(quizVO)
            return render_template("admin/editQuiz.html", quizVOList=quizVOList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route("/admin/updateQuiz", methods=['POST'])
def adminUpdateQuiz():
    try:
        if adminLoginSession() == "admin":
            quizId = request.form['quizId']
            quizQuestion = request.form['quizQuestion']
            quizAnswer = request.form['quizAnswer']

            quizVO = QuizVO()
            quizDAO = QuizDAO()

            quizVO.quizQuestion = quizQuestion
            quizVO.quizAnswer = quizAnswer
            quizVO.quizId = quizId

            quizDAO.updateQuiz(quizVO)

            return redirect(url_for("adminViewQuiz"))
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)
