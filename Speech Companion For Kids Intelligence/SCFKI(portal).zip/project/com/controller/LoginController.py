import random
import smtplib
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from flask import render_template, request, session, redirect, url_for

from project import app
from project.com.dao.ComplainDAO import ComplainDAO
from project.com.dao.FactDAO import FactDAO
from project.com.dao.FactTypeDAO import FactTypeDAO
from project.com.dao.FeedbackDAO import FeedbackDAO
from project.com.dao.LoginDAO import LoginDAO
from project.com.dao.PoemDAO import PoemDAO
from project.com.dao.StoryDAO import StoryDAO
from project.com.dao.StoryTypeDAO import StoryTypeDAO
from project.com.vo.LoginVO import LoginVO


@app.route('/', methods=['GET'])
def adminLoadLogin():
    try:
        return render_template("admin/login.html")
    except Exception as ex:
        print(ex)


@app.route('/admin/validateLogin', methods=['GET', 'POST'])
def adminValidateLogin():
    try:
        loginUsername = request.form['loginUsername']
        loginPassword = request.form['loginPassword']

        loginVO = LoginVO()
        loginDAO = LoginDAO()

        loginVO.loginUsername = loginUsername
        loginVO.loginPassword = loginPassword
        loginVO.loginStatus = "active"

        loginVOList = loginDAO.validateLogin(loginVO)

        loginDictList = [i.as_dict() for i in loginVOList]

        lenLoginDictList = len(loginDictList)

        if lenLoginDictList == 0:
            msg = "Username or Password Incorrect!!!"
            return render_template("admin/login.html", error=msg)

        elif len([i.as_dict() for i in loginDAO.validateLoginStatus(loginVO)]) == 0:
            msg = "You are blocked by admin! Please contact admin."
            return render_template("admin/login.html", error=msg)

        else:
            for row1 in loginDictList:
                loginId = row1['loginId']
                loginUsername = row1['loginUsername']
                loginRole = row1['loginRole']

                session['session_loginId'] = loginId
                session['session_loginUsername'] = loginUsername
                session['session_loginRole'] = loginRole

                session.permanent = True

                if loginRole == "admin":
                    return redirect(url_for('adminLoadDashboard'))
                else:
                    return redirect(url_for('userLoadDashboard'))
    except Exception as ex:
        print(ex)


@app.route('/admin/loadDashboard', methods=['GET'])
def adminLoadDashboard():
    try:
        if adminLoginSession() == 'admin':
            totalRating = 0
            fiveStartRatings = 0
            fourStarRatings = 0
            threeStarRatings = 0
            twoStarRatings = 0
            oneStarRatings = 0

            loginDAO = LoginDAO()
            complainDAO = ComplainDAO()
            feedbackDAO = FeedbackDAO()

            users = loginDAO.getUserCount()
            activeUsers = loginDAO.getActiveUser()
            complains = complainDAO.totalComplains()
            pendingComplains = complainDAO.totalPendingComplains()
            feedbackList = [i[0].as_dict() for i in feedbackDAO.viewFeedback()]
            feedbacks = feedbackDAO.totalFeedbacks()
            unreviewedFeedbacks = feedbackDAO.totalUnreviewedFeedbacks()

            for feedback in feedbackList:
                totalRating += feedback['feedbackRating']
            if len(feedbackList) != 0:
                avarageRating = "{:.2f}".format(totalRating / len(feedbackList))
            else:
                avarageRating = 0

            for feedback in feedbackList:
                if feedback['feedbackRating'] == 5:
                    fiveStartRatings += 1
                elif feedback['feedbackRating'] == 4:
                    fourStarRatings += 1
                elif feedback['feedbackRating'] == 3:
                    threeStarRatings += 1
                elif feedback['feedbackRating'] == 2:
                    twoStarRatings += 1
                else:
                    oneStarRatings += 1

            return render_template("admin/dashboard.html", users=users, activeUsers=activeUsers, complains=complains,
                                   pendingComplains=pendingComplains, avarageRating=avarageRating,
                                   feedbackList=feedbackList,
                                   feedbacks=feedbacks, unreviewedFeedbacks=unreviewedFeedbacks,
                                   fiveStartRatings=fiveStartRatings, fourStarRatings=fourStarRatings,
                                   threeStarRatings=threeStarRatings, twoStarRatings=twoStarRatings,
                                   oneStarRatings=oneStarRatings)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/user/loadDashboard')
def userLoadDashboard():
    try:
        if adminLoginSession() == 'user':
            totalRating = 0
            fiveStartRatings = 0
            fourStarRatings = 0
            threeStarRatings = 0
            twoStarRatings = 0
            oneStarRatings = 0

            loginDAO = LoginDAO()
            storyTypeDAO = StoryTypeDAO()
            storyDAO = StoryDAO()
            factTypeDAO = FactTypeDAO()
            factDAO = FactDAO()
            complainDAO = ComplainDAO()
            feedbackDAO = FeedbackDAO()
            poemDAO = PoemDAO()

            storyTypeList = storyTypeDAO.viewStoryType()
            storyList = storyDAO.viewStory()
            factTypeList = factTypeDAO.viewFactType()
            factList = factDAO.viewFact()
            complains = complainDAO.totalUserComplains(session['session_loginId'])
            pendingComplains = complainDAO.totalUserPendingComplains(session['session_loginId'])
            userFeedbacks = feedbackDAO.totalUserFeedbacks(session['session_loginId'])
            unreviewedFeedbacks = feedbackDAO.totalUserUnreviewedFeedbacks(session['session_loginId'])
            poemList = poemDAO.viewPoem()
            feedbackList = [i[0].as_dict() for i in feedbackDAO.viewFeedback()]
            userList = loginDAO.getUserList()

            for feedback in feedbackList:
                totalRating += feedback['feedbackRating']
            if len(feedbackList) != 0:
                avarageRating = "{:.2f}".format(totalRating / len(feedbackList))
            else:
                avarageRating = 0

            for feedback in feedbackList:
                if feedback['feedbackRating'] == 5:
                    fiveStartRatings += 1
                elif feedback['feedbackRating'] == 4:
                    fourStarRatings += 1
                elif feedback['feedbackRating'] == 3:
                    threeStarRatings += 1
                elif feedback['feedbackRating'] == 2:
                    twoStarRatings += 1
                else:
                    oneStarRatings += 1

            return render_template("user/dashboard.html", storyTypeList=storyTypeList, storyList=storyList,
                                   factTypeList=factTypeList, factList=factList, complains=complains,
                                   pendingComplains=pendingComplains, userFeedbacks=userFeedbacks,
                                   avarageRating=avarageRating, fiveStartRatings=fiveStartRatings,
                                   fourStarRatings=fourStarRatings, threeStarRatings=threeStarRatings,
                                   twoStarRatings=twoStarRatings, oneStarRatings=oneStarRatings,
                                   feedbackList=feedbackList, unreviewedFeedbacks=unreviewedFeedbacks,
                                   poemList=poemList, feedbacks=len(feedbackList), userList=userList)
        else:
            return redirect(url_for("adminLogoutSession"))
    except Exception as ex:
        print(ex)


@app.route('/admin/loginSession')
def adminLoginSession():
    if 'session_loginId' and 'session_loginRole' in session:

        print("<<<<<<<<<<<<<<<<True>>>>>>>>>>>>>>>>>>>>")

        if session['session_loginRole'] == 'admin':

            return "admin"

        elif session['session_loginRole'] == 'user':

            return "user"

    else:

        print("<<<<<<<<<<<<<<<<False>>>>>>>>>>>>>>>>>>>>")

        return False


@app.route("/admin/logoutSession", methods=['GET'])
def adminLogoutSession():
    session.clear()
    return redirect(url_for('adminLoadLogin'))


@app.route('/user/loadForgetPassword')
def userLoadForgetPassword():
    try:
        return render_template('user/forgetPassword.html')
    except Exception as ex:
        print(ex)


@app.route('/user/generateOTP', methods=['POST'])
def userGenerateOTP():
    try:
        loginDAO = LoginDAO()
        loginVO = LoginVO()

        loginUsername = request.form['loginUsername']
        loginVO.loginUsername = loginUsername

        LoginDictList = [i.as_dict() for i in loginDAO.validateLoginUsername(loginVO)]

        if len(LoginDictList) != 0:
            passwordOTP = ''.join((random.choice(string.digits)) for x in range(4))
            session['session_OTP'] = passwordOTP
            session['session_loginUsername'] = loginUsername
            session['session_loginId'] = LoginDictList[0]['loginId']
            sender = "scki.alexa@gmail.com"
            receiver = loginUsername
            msg = MIMEMultipart()
            msg['From'] = sender
            msg['To'] = receiver
            msg['subject'] = "ACCOUNT PASSWORD"
            msg.attach(MIMEText('OTP to reset password is:'))
            msg.attach(MIMEText(passwordOTP, 'plain'))
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(sender, "42734599")
            text = msg.as_string()
            server.sendmail(sender, receiver, text)
            server.quit()
            return render_template('user/addOTP.html')

        else:
            error = "The given Username is not registered yet!"
            return render_template("admin/login.html", error=error)
    except Exception as ex:
        print(ex)


@app.route('/user/validateOTP', methods=['POST'])
def userValidateOTP():
    try:
        passwordOTP = request.form['passwordOTP']

        if passwordOTP == session['session_OTP']:
            loginPassword = ''.join((random.choice(string.ascii_letters + string.digits)) for x in range(8))
            loginUsername = session['session_loginUsername']
            sender = "scki.alexa@gmail.com"
            receiver = loginUsername
            msg = MIMEMultipart()
            msg['From'] = sender
            msg['To'] = receiver
            msg['subject'] = "Reset Password"
            msg.attach(MIMEText('Your new Password is:'))
            msg.attach(MIMEText(loginPassword, 'plain'))
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(sender, "42734599")
            text = msg.as_string()
            server.sendmail(sender, receiver, text)
            server.quit()

            loginVO = LoginVO()
            loginDAO = LoginDAO()

            loginVO.loginUsername = loginUsername
            loginVO.loginId = session['session_loginId']
            loginVO.loginPassword = loginPassword

            loginDAO.updateLogin(loginVO)

            return render_template("admin/login.html", error="Your new password is sent to your email address!")
        else:
            return render_template('user/addOTP.html', error="Invalid OTP, Please ty again!")
    except Exception as ex:
        print(ex)


@app.route('/user/loadResetPassword')
def userLoadResetPassword():
    try:
        if adminLoginSession() == 'user':
            return render_template('user/resetPassword.html')
        else:
            return redirect(url_for("adminLogoutSession"))

    except Exception as ex:
        print(ex)


@app.route('/user/resetPassword', methods=['POST'])
def userResetPassword():
    try:
        if adminLoginSession() == 'user':
            oldLoginPassword = request.form['oldLoginPassword']
            newLoginPassword = request.form['newLoginPassword']

            loginVO = LoginVO()
            loginDAO = LoginDAO()

            loginVO.loginId = session['session_loginId']
            loginVO.loginUsername = session['session_loginUsername']
            loginVO.loginPassword = oldLoginPassword

            if len([i.as_dict() for i in loginDAO.validateLogin(loginVO)]) != 0:
                loginVO.loginPassword = newLoginPassword
                loginDAO.updateLogin(loginVO)
                return render_template("user/dashboard.html")
            else:
                return render_template('user/resetPassword.html',
                                       error="Invalid old password,please enter valid Password!")

        else:
            return redirect(url_for("adminLogoutSession"))

    except Exception as ex:
        print(ex)
